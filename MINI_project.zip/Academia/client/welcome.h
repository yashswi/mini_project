void welcome_screen(){
	system("clear");
	
	printf("\nWelcome to Academia\n");
	sleep(1);
	printf("\nConnecting to server\n");
	sleep(1);
	system("clear");
	printf("\nWelcome to Academia\n");
	printf("\nConnecting to server.\n");
	sleep(1);
	system("clear");

	printf("\nWelcome to Academia\n");
	printf("\nConnecting to server.\n");
	sleep(1);
	system("clear");
	printf("\nWelcome to Academia\n");
	printf("\nConnecting to server.\n");
	sleep(1);
	system("clear");
}
